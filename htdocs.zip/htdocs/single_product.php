<?php include('header.php'); ?>


<?php

include('connection.php');

if(isset($_GET['itemNum'])){

   $itemNum =  $_GET['itemNum'];

    $stmt = $db->prepare("SELECT * FROM products WHERE itemNum = ?");
    $stmt->bind_param("i",$itemNum);

    $stmt->execute();


    $product = $stmt->get_result();//[]


}


?>






      <!--Single product-->
      <section class="container single-product my-5 pt-5">
        <div class="row mt-5">

          <?php  while($row = $product->fetch_assoc()){ ?>

       
          
            <div class="col-lg-5 col-md-6 col-sm-12">
                <img class="img-fluid w-100 pb-1" src="Product Images/<?php echo $row['merchImagePath']; ?>" id="mainImg"/>
                <div class="small-img-group">
                    <div class="small-img-col">
                        <img src="Product Images/<?php echo $row['merchImagePath']; ?>" width="100%" class="small-img"/>
                    </div>
                    <div class="small-img-col">
                        <img src="Product Images/<?php echo $row['merchImagePath']; ?>" width="100%" class="small-img"/>
                    </div>
                    <div class="small-img-col">
                        <img src="Product Images/<?php echo $row['merchImagePath']; ?>" width="100%" class="small-img"/>
                    </div>
                    <div class="small-img-col">
                        <img src="Product Images/<?php echo $row['merchImagePath']; ?>" width="100%" class="small-img"/>
                    </div>
                </div>
            </div>

           


            <div class="col-lg-6 col-md-12 col-12">
                <h6>Men/Shoes</h6>
                <h3 class="py-4"><?php echo $row['title']; ?></h3>
                <h2>$<?php echo $row['price']; ?></h2>

                <form method="POST" action="cart.php">
                  <input type="hidden" name="itemNum" value="<?php echo $row['itemNum']; ?>" />
                  <input type="hidden" name="merchImagePath" value="<?php echo $row['merchImagePath']; ?>"/>  
                  <input type="hidden" name="title" value="<?php echo $row['title']; ?>"/>
                  <input type="hidden" name="price" value="<?php echo $row['price']; ?>"/>
                  
                      <input type="number" name="product_quantity" value="1"/>
                      <button class="buy-btn" type="submit" name="add_to_cart">Add To Cart</button>
                </form>

               
                <h4 class="mt-5 mb-5">Product details</h4>
                <span><?php echo $row['product_description']; ?>
                </span>
            </div>

        

            <?php } ?>

        </div>
     
    

         <!--Footer-->
    <footer class="mt-5 py-5">
        <div class="row container mx-auto pt-5">
          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
            <img class="logo" src="Product Images/logo.jpeg"/>
            <p class="pt-3">We provide the best products for the most affordable prices</p>
          </div>
          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
           <h5 class="pb-2">Featured</h5>
           <ul class="text-uppercase">
             <li><a href="#">men</a></li>
             <li><a href="#">women</a></li>
             <li><a href="#">boys</a></li>
             <li><a href="#">girls</a></li>
             <li><a href="#">new arrivals</a></li>
             <li><a href="#">clothes</a></li>
           </ul>
          </div>

          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
            <h5 class="pb-2">Contact Us</h5>
            <div>
              <h6 class="text-uppercase">Address</h6>
              <p>1234 Street Name, City</p>
            </div>
            <div>
              <h6 class="text-uppercase">Phone</h6>
              <p>123 456 7890</p>
            </div>
            <div>
              <h6 class="text-uppercase">Email</h6>
              <p>info@email.com</p>
            </div>
          </div>
          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
            <h5 class="pb-2">Instagram</h5>
            <div class="row">
              <img src="Product Images/featured1.jpeg" class="img-fluid w-25 h-100 m-2"/>
              <img src="Product Images/featured2.jpeg" class="img-fluid w-25 h-100 m-2"/>
              <img src="Product Images/featured3.jpeg" class="img-fluid w-25 h-100 m-2"/>
              <img src="Product Images/featured4.jpeg" class="img-fluid w-25 h-100 m-2"/>
              <img src="Product Images/clothes1.jpeg" class="img-fluid w-25 h-100 m-2"/>
            </div>
          </div>
        </div>



        <div class="copyright mt-5">
          <div class="row container mx-auto">
            <div class="col-lg-3 col-md-5 col-sm-12 mb-4">
              <img src="Product Images/payment.jpeg"/>
            </div>
            <div class="col-lg-3 col-md-5 col-sm-12 mb-4 text-nowrap mb-2">
              <p>eCommerce @ 2025 All Right Reserved</p>
            </div>
            <div class="col-lg-3 col-md-5 col-sm-12 mb-4">
             <a href="#"><i class="fab fa-facebook"></i></a>
             <a href="#"><i class="fab fa-instagram"></i></a>
             <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
          </div>
        </div>

    </footer>







    

    <script>

     var mainImg = document.getElementById("mainImg");
     var smallImg = document.getElementsByClassName("small-img"); 


     for(let i=0; i<4; i++){
                    smallImg[i].onclick = function(){
                    mainImg.src = smallImg[i].src;
                }

     }

  



    </script>





<?php include('layouts/footer.php'); ?>