<!DOCTYPE html>
session_start();
<html lang="en">

<?php include('header.php'); 
      include('connection.php');?>
      <!--Home-->
      <section id="home">
      	<div class="container">
	<?php
		$query = "SELECT imagePath FROM image GROUP BY imageNum";
		$image_path = mysqli_query($db, $query);
		$rows = mysqli_fetch_all($image_path, MYSQLI_BOTH);
		foreach ($rows as $row) {
			echo '<img class="img-fluid" src="'.$row[0].'" width="250" height = "250"/>';
		}
	
	?>
	</div>
	</section>
    
      <!--Featured-->
      <section id="Phonecases" class="my-5 pb-5">
        <div class="container text-center mt-5 py-5">
          <h3>Phonecases</h3>
          
          <p>---------------------------------</p>
        </div>
	       <div class="grid-container">
		      <?php
			     $query = "SELECT * FROM products WHERE merchType = 'phonecase' GROUP BY itemNum";
			     $prodInfo = mysqli_query($db, $query);
			     $rows = mysqli_fetch_all($prodInfo, MYSQLI_BOTH);
			     foreach ($rows as $row) {
				      echo '
				      <div class="grid-item">
					     <div onclick="window.location.href=\'single_product.php\'" class="product text-center col-lg-3 col-md-4 col-sm-12">
            				<img class="img-fluid mb-3" src="'.$row['merchImagePath'].'" width="200" height="auto"/>
            					<div class="star">
              						<i class="fas fa-star"></i>
              						<i class="fas fa-star"></i>
              						<i class="fas fa-star"></i>
              						<i class="fas fa-star"></i>
              						<i class="fas fa-star"></i>
            					</div>
            					<h5 class="p-name">'.$row['title'].'</h5>
            					<h4 class="p-price">$'.$row['price'].'</h4>
           					<a href="single_product.php?itemNum="'. $row["itemNum"].'"><button class="buy-btn">Buy Now</button></a>  
					     </div>
				     </div>';
			     }
		      ?>
	     </div>	
    
      </section>

      <section id="Tees" class="my-5 pb-5">
        <div class="container text-center mt-5 py-5">
          <h4>T-shirts</h4>
          
          <p>---------------------------------</p>
        </div>
         <div class="grid-container">
          <?php
           $query = "SELECT * FROM products WHERE merchType = 'tshirt' GROUP BY itemNum";
           $prodInfo = mysqli_query($db, $query);
           $rows = mysqli_fetch_all($prodInfo, MYSQLI_BOTH);
           foreach ($rows as $row) {
              echo '
              <div class="grid-item">
               <div onclick="window.location.href=\'single_product.php\'" class="product text-center col-lg-3 col-md-4 col-sm-12">
                    <img class="img-fluid mb-3" src="'.$row['merchImagePath'].'" width="200" height="auto"/>
                      <div class="star">
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                      </div>
                      <h5 class="p-name">'.$row['title'].'</h5>
                      <h4 class="p-price">$'.$row['price'].'</h4>
                    <a href="single_product.php?itemNum="'. $row["itemNum"].'"><button class="buy-btn">Buy Now</button></a>  
               </div>
             </div>';
           }
          ?>
       </div> 
    
      </section>

      <section id="Sweatshirts" class="my-5 pb-5">
        <div class="container text-center mt-5 py-5">
          <h5>Sweatshirts</h5>
          
          <p>---------------------------------</p>
        </div>
         <div class="grid-container">
          <?php
           $query = "SELECT * FROM products WHERE merchType = 'sweatshirt' GROUP BY itemNum";
           $prodInfo = mysqli_query($db, $query);
           $rows = mysqli_fetch_all($prodInfo, MYSQLI_BOTH);
           foreach ($rows as $row) {
              echo '
              <div class="grid-item">
               <div onclick="window.location.href=\'single_product.php\'" class="product text-center col-lg-3 col-md-4 col-sm-12">
                    <img class="img-fluid mb-3" src="'.$row['merchImagePath'].'" width="200" height="auto"/>
                      <div class="star">
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                      </div>
                      <h5 class="p-name">'.$row['title'].'</h5>
                      <h4 class="p-price">$'.$row['price'].'</h4>
                    <a href="single_product.php?itemNum="'. $row["itemNum"].'"><button class="buy-btn">Buy Now</button></a> 
               </div>
             </div>';
           }
          ?>
       </div> 
    
      </section>

   



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
</html>