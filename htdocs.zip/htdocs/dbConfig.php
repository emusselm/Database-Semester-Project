<?php  
// Database configuration  
$dbHost     = "localhost";  
$dbUsername = "root";  
$dbPassword = "IloveSumire2022!";  
$dbName     = "store";  
?>