<?php


$db = mysqli_connect("localhost:3306","root","","store")
        or die("Couldn't connect to database");

?>





