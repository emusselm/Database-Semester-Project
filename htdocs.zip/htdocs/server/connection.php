<?php


$conn = mysqli_connect("localhost:3306","root","","store")
        or die("Couldn't connect to database");
		
mysqli_select_db($conn, "store") or die("Database Error");
        if($conn != true){
                mysqli_close($conn);
        }

?>





